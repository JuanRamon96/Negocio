## Smart Point ##

** Enlace al documento con las modificacinoes **

https://docs.google.com/document/d/1r4xLraifdcva_CLoZqxxaBEqRjixPRxz_VGVGEmob-8/edit?usp=sharing
